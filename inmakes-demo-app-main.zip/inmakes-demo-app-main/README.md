## InmakesEdu App UI 

<div style="display: flex;flex-direction:'row';">
<img src="https://user-images.githubusercontent.com/81835507/203560989-f5bbc804-7331-40a1-8742-2aa843a37cb0.jpg" width=15% height=15%>
<img src="https://user-images.githubusercontent.com/81835507/203561019-a32ccb3a-a993-4a45-b272-d7a984b0f7dd.jpg" width=15% height=15%>
<img src="https://user-images.githubusercontent.com/81835507/203561055-d59572d2-7a30-42a8-acb7-ce163371285c.jpg" width=15% height=15%>
<img src="https://user-images.githubusercontent.com/81835507/203561076-70500575-7593-440f-bf5f-35f99ffdceda.jpg" width=15% height=15%>
<img src="https://user-images.githubusercontent.com/81835507/203561084-0f03c09d-dc0b-474c-b388-b069e2218861.jpg" width=15% height=15%>
</div>

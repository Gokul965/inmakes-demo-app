import React, { Component } from 'react'
import { Text, View } from 'react-native'

export default class Recents extends Component {
  render() {
    return (
      <View>
        <Text>Recents</Text>
      </View>
    )
  }
}

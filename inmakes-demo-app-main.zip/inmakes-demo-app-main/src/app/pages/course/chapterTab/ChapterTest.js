import React, { Component } from 'react'
import { Text, View } from 'react-native'

export default class ChapterTest extends Component {
  render() {
    return (
     <View>
        <Text>Chapter Test</Text>
     </View>
    )
  }
}

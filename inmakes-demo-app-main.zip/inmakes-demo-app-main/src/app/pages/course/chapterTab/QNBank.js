import React, { Component } from 'react'
import { Text, View } from 'react-native'

export default class QNBank extends Component {
  render() {
    return (
     <View>
        <Text>QN Bank</Text>
     </View>
    )
  }
}

export const COLOR = {
  mainColor: '#0d1b29',
  textFieldColor: '#1d2f3d',
  borderColor: '#2d4252',
  buttonColor: '#28a745',
  lightGrey: '#b8b8b8',
  textColor: '#c4e7ff',
  transparantColor:'#FFFFFF00'
};
